# BpkSecurityAuditScanner

This project is designed to start a security audit on the local host. 
The scan is transparent and leaves no trace on the target.

### 1. Requirements

1. Red Hat 8.x or Red Hat 9.x

### 2. Usage

Run the script as root or with sudo:
```bash
sudo bash scan.sh
```
At the end of the script execution, a ZIP file containing the scan reports is created. 
After that the ZIP file will be available in the same place as the script.

#### Reports structure
```
BPK-Audit-Reports_{{hostname}}(.zip)
├── sources
│   ├── CIS-l1-Results_{{hostname}}.xml                         -> XML results of CIS Level 1 scan
│   ├── CIS-l2-Results_{{hostname}}.xml                         -> XML results of CIS Level 2 scan
│   └── Vulnerability-Scan-Results_{{hostname}}.xml             -> XML results of vulnerability scan
├── reports
│   ├── CIS-l1-Report_{{hostname}}.html                         -> HTML report of CIS Level 1 scan
│   ├── CIS-l2-Report_{{hostname}}.html                         -> HTML report of CIS Level 2 scan
│   └── Vulnerability-Scan-Report_{{hostname}}.html             -> HTML report of vulnerability scan
└── BPK-System-Assessment.txt                                   -> TXT file containing kickstart version, installed RPM list, open ports 
```