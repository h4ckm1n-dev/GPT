#!/usr/bin/env bash

##################################################################################
# Brief : This script start a CIS benchmark and a vulnerability scan on the client
##################################################################################

# --------------------------------------------------------------------

# Check if script is launched with root user
if [ $UID -ne 0 ]
then
    printf "This script requires root privileges!"
    exit 1
fi

# --------------------------------------------------------------------

# Check if OpenSCAP is installed
if ! rpm -qa | grep -q openscap-scanner
then
	printf "OpenSCAP is not installed!\nOpenSCAP installation...\n"
	yum install -y openscap-scanner scap-security-guide > /dev/null 2>&1
    uninstall_required=true
else
	printf "OpenSCAP is already installed!\n"
    uninstall_required=false
fi

# --------------------------------------------------------------------

# Get server hostname and OS version ("rhel8" or "rhel9")
hostname=$(hostname -f)

if grep -q "Red Hat Enterprise Linux" "/etc/redhat-release"
then
    os="rhel"
    os+=$(cat /etc/redhat-release | cut -d ' ' -f6 | head -c -3)
    os_u=${os^^}
fi

# --------------------------------------------------------------------

# Get KS informations
printf "Get kickstart informations...\n"
filepath=/etc/ks_version.txt
if ! test -f "$filepath"
then
    filepath=/opt/support/
    rhelfolder=$(ls $filepath | grep 'RHEL_')
    filepath+=$rhelfolder
    filepath+=/ks_version.txt
fi

if test -f "$filepath"
then
    cp $filepath ./BPK-System-Assessment.txt
    echo -e "\n\n" >> BPK-System-Assessment.txt
else
    touch ./BPK-System-Assessment.txt
fi

# --------------------------------------------------------------------

# Get open ports
printf "Get open ports...\n"
echo -e "Open ports:\n--------------------\n" >> BPK-System-Assessment.txt
netstat -nltp >> BPK-System-Assessment.txt

# --------------------------------------------------------------------

# Get installed packages
printf "Get installed packages...\n"
echo -e "Installed packages:\n--------------------\n" >> BPK-System-Assessment.txt
rpm -qa >> BPK-System-Assessment.txt

# --------------------------------------------------------------------

# Creating report folder structure
printf "Creating report folder structure...\n"
mkdir sources reports

# --------------------------------------------------------------------

# OpenSCAP CIS Benchmark Level 1
printf "Starting CIS l1 benchmark...\n"
oscap xccdf eval --profile xccdf_org.ssgproject.content_profile_cis_server_l1 --results sources/CIS-l1-Results_$hostname.xml --report ./reports/CIS-l1-Report_$hostname.html /usr/share/xml/scap/ssg/content/ssg-$os-ds.xml > /dev/null 2>&1

# OpenSCAP CIS Benchmark Level 2
printf "Starting CIS l2 benchmark...\n"
oscap xccdf eval --profile xccdf_org.ssgproject.content_profile_cis_server_l2 --results sources/CIS-l2-Results_$hostname.xml --report ./reports/CIS-l2-Report_$hostname.html /usr/share/xml/scap/ssg/content/ssg-$os-ds.xml > /dev/null 2>&1

# OpenSCAP Vulnerability Scan
printf "Starting vulnerability scan...\n"
oscap oval eval --results ./sources/Vulnerability-Scan-Results_$hostname.xml --report reports/Vulnerability-Scan-Report_$hostname.html ./eval/com.redhat.rhsa-$os_u.xml > /dev/null 2>&1

# --------------------------------------------------------------------

# Creating a ZIP file with reports
printf "Moving reports in ZIP file...\n"
zip -r --move --quiet BPK-Audit-Reports_$hostname.zip sources/ reports/ BPK-System-Assessment.txt
rm -r sources/ reports/

# --------------------------------------------------------------------

# Check if OpenSCAP is installed
if $uninstall_required
then
    printf "Uninstallation of OpenSCAP...\n"
    yum remove -y openscap-scanner scap-security-guide > /dev/null 2>&1
    rm -r /usr/share/xml/scap
fi